export interface NavItemInterface {
  path: string,
  title: string
}
