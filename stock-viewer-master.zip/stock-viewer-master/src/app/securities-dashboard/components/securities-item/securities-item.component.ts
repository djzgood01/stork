import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-securities-item',
  template: `
    <p>
      securities-item works!
    </p>
  `,
  styleUrls: ['./securities-item.component.scss']
})
export class SecuritiesItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
