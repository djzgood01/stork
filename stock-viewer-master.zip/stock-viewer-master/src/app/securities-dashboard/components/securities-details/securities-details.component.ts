import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-securities-details',
  template: `
    <p>
      securities-details works!
    </p>
  `,
  styleUrls: ['./securities-details.component.scss']
})
export class SecuritiesDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
