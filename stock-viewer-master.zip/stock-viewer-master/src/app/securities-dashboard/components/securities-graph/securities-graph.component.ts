import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-securities-graph',
  template: `
    <p>
      securities-graph works!
    </p>
  `,
  styleUrls: ['./securities-graph.component.scss']
})
export class SecuritiesGraphComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
