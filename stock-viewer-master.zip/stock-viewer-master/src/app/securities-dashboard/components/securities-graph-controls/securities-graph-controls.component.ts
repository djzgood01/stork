import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-securities-graph-controls',
  template: `
    <p>
      securities-graph-controls works!
    </p>
  `,
  styleUrls: ['./securities-graph-controls.component.scss']
})
export class SecuritiesGraphControlsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
