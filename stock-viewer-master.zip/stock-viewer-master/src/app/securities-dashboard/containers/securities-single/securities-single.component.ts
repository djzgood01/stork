import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-securities-single',
  template: `
    <p>
      securities-single works!
    </p>
  `,
  styleUrls: ['./securities-single.component.scss']
})
export class SecuritiesSingleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
